import { Router, history } from './Router';

export { Router, history };
